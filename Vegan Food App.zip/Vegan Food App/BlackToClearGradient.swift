//
//  BlackToClearGradient.swift
//  Vegan Food App
//
//  Created by Raneem Soufi on 10/2/20.
//

import Foundation
