//
//  RecipeViewController.swift
//  Vegan Food App
//
//  Created by Raneem Soufi on 9/30/20.
//

import UIKit

class RecipeViewController: UIViewController {
    
    @IBOutlet weak var ReturnButton: UIButton!
    
    @IBOutlet weak var InformationView: UIView!
    @IBOutlet weak var BackgroundImage: UIImageView!
    @IBOutlet weak var MealName: UILabel!
    
    @IBOutlet weak var TimeLabel: UILabel!
    
    @IBOutlet weak var Ingredients: UICollectionView!
    @IBOutlet weak var MakeRecipeButton: UIButton!
    
    var cellHeight: Double = 0
    
    
    
    var meal: Meal = Meal()
    private let sectionInsets = UIEdgeInsets(top: 10.0, left: 20.0, bottom: 10.0, right: 20.0)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        meal.printMeal()
        // Do any additional setup after loading the view.
        self.BackgroundImage.image = meal.picture
        self.MealName.text = meal.name
        self.InformationView
            .layer.cornerRadius = 20
        self.InformationView.clipsToBounds = true
        
        self.ReturnButton.backgroundColor = UIColor.systemGreen.withAlphaComponent(0.5)
        self.ReturnButton.layer.cornerRadius = 20
        self.ReturnButton.clipsToBounds = true
        
        self.Ingredients.delegate = self
        self.Ingredients.dataSource = self
        self.view.backgroundColor = UIColor.systemGreen
        //self.Ingredients.reloadData()
        
        //Calculate the amount of time needed
        var timeInMinutes = meal.time
        if(meal.time == 0){
            self.TimeLabel.text = "Very little time"
        } else{
            let timeInHours:Int = Int(floor(Double(meal.time/60)))
            timeInMinutes = timeInMinutes - (Int(timeInHours)*60)
            if(timeInHours == 1){
                self.TimeLabel.text = "\(timeInHours) hour, \(timeInMinutes) minutes"
            } else if (timeInHours > 1){
                self.TimeLabel.text = "\(timeInHours) hours, \(timeInMinutes) minutes"
            } else{
                self.TimeLabel.text = "\(timeInMinutes) minutes"
            }
            
        }
    }
    
    override func viewDidLayoutSubviews() {
        let gradientLayer = CAGradientLayer()
        let Color1: UIColor = UIColor.black.withAlphaComponent(0.3)
        let Color2: UIColor = UIColor.black.withAlphaComponent(0)
        gradientLayer.colors = [Color2.cgColor, Color2.cgColor, Color1.cgColor]
        gradientLayer.frame = CGRect.zero
        //gradientLayer.startPoint =
        
        //cell.GradientView.layer.
        
        self.BackgroundImage.layer.insertSublayer(gradientLayer, above: self.BackgroundImage.layer)
        gradientLayer.frame = self.BackgroundImage.layer.bounds
    
    }
    

    //MARK: Events
    @IBAction func Return(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func MakeRecipeButtonPress(_ sender: Any) {
    }
    
}

extension RecipeViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return meal.ingredients.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "IngredientsCell", for: indexPath) as! IngredientsCell
        print("number of ingredients: \(meal.ingredientPictures.count)")
        print("number of pics: \(meal.ingredients.count)")
        
        cell.Image.image = meal.ingredientPictures[indexPath.item]
        cell.Title.text = meal.ingredients[indexPath.item]
        
        cell.layer.cornerRadius = 10
        cell.clipsToBounds = true
        
        cell.Image.layer.cornerRadius = 10
        cell.Image.clipsToBounds = true
        
        if(Double(cell.bounds.height ) > cellHeight){
            cellHeight = Double(cell.bounds.height)
        }
        
        
        return cell
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let screenSize = UIScreen.main.bounds
        let screenWidth = screenSize.width
        return CGSize(width: screenWidth/2 - sectionInsets.left - sectionInsets.right, height: collectionView.bounds.height - sectionInsets.bottom - sectionInsets.top)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return sectionInsets
    }
}

class IngredientsCell: UICollectionViewCell{
    
    @IBOutlet weak var Title: UILabel!
    @IBOutlet weak var Image: UIImageView!


}
