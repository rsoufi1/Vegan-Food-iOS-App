//
//  ViewController.swift
//  Vegan Food App
//
//  Created by Raneem Soufi on 9/18/20.
//

import UIKit

class ViewController: UIViewController {
    var meals: [Meal] = []
    
    @IBOutlet weak var button: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let url = (URL(string: "https://api.edamam.com/search?q=vegan&app_id=b0e790d0&app_key=2b9e77a8e64c0c00a325ed44719fdb8a&health=vegan&from=0&to=10")!) as URL
        meals = []
        
        let task: URLSessionDataTask = URLSession.shared.dataTask(with: url) { (data, response, error) in
           
            if error == nil{
                if let content = data{
                    do{
                        let jsonResult = try? (JSONSerialization.jsonObject(with: content, options: JSONSerialization.ReadingOptions.mutableContainers) as? [String: Any])
                        let result2 = jsonResult?["hits"] as? [Any]
                        //print(result2)
                        //print(result2?[1])
                        var c: Int = result2?.count ?? 0
                        for i in 0...c-1{
                            let item = result2?[i] as? [String: Any]
                            let anotherItem = (item?["recipe"]) as? [String: Any]
                            //print(anotherItem?["label"])
                            print(anotherItem?["totalTime"])
                            let m = try Meal(json: anotherItem!)
                            //print(m.name)
                            self.meals.append(m)
                            //print(self.meals.count)
                        }
                        
                        print("works")
                    } catch {
                        print("nope")
                    }
                }
               
            }
           
        }
        task.resume()
        print()
        print()
        if(meals.count - 1 < 0){
            print("idk what happened")
        } else{
            for i in 0...self.meals.count-1{
                print( self.meals[i].name)
            }
        }
        
        print("done")
       // print(result[0])
    }
    
    
    @IBAction func buttonPress(_ sender: Any) {
        print()
        print()
        if(meals.count - 1 < 0){
            print("idk what happened")
        } else{
            for i in 0...self.meals.count-1{
                print( self.meals[i].printMeal())
            }
        }
    }
    
}

