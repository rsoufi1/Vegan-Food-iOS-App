//
//  Meal.swift
//  Vegan Food App
//
//  Created by Raneem Soufi on 9/21/20.
//

import Foundation
import UIKit

struct Meal{
    let name: String
    let ingredients: [String]
    let ingredientPictures: [UIImage]
    let time: Int
    let picture: UIImage
    
    //MARK: METHODS
    func printMeal(){
        print("name: " + name)
        print("time: \(time)")
        print("ingredients: ")
        for i in 0...ingredients.count - 1{
            print("\t\(ingredients[i])")
        }
    }
}

extension Meal{
    init(json: [String: Any]) throws{
        guard let name = json["label"] as? String
        else {
            throw SerializationError.missing("label")
        }
        
        guard let ingred = json["ingredientLines"] as? [String]
        else{
            throw SerializationError.missing("ingredients")
        }
        
        guard let time = json["totalTime"] as? Int
        else {
            throw SerializationError.missing("time")
        }
        guard let pic = json["image"] as? String
        else{
            throw SerializationError.missing("image")
        }
        
        self.name = name
        //self.ingredients = ingred
        self.time = time
        
        //Get image
        let imageURL = URL(string: pic)
        
        if let data = try? Data(contentsOf: imageURL!) {
                // Create Image and Update Image View
            self.picture = UIImage(data: data)!
        } else{
            self.picture = UIImage.init(named: "NoImage")!//default image
        }
        
       //Get all the images for ingredients
        guard let ingredientsArray = json["ingredients"] as? [[String: Any]]
        else{
            throw SerializationError.missing("image")
        }
  
        //print(ingredientsArray[0])
        var ingredArray2: [String: Any] = ["": ""]
        var tempIngredientNames: [String] = [String]()
        
        var urls: [String] = []
        for i in 0...ingredientsArray.count - 1{
            ingredArray2 = ingredientsArray[i] as? [String: Any] ?? ["no": "no"]
            urls.append(ingredArray2["image"] as? String ?? "no")
            tempIngredientNames.append(ingredArray2["text"] as? String ?? "no")
        }
        
        self.ingredients = tempIngredientNames
        //print(ingredArray2)
        //print(urls)
        //let ingredientsImagesStrings = (ingredientsArray["image"]) as? [String]
        
        var tempIngredients: [UIImage] = [UIImage]()
        
        
        for each in urls{
            let url = URL(string: each)
            if(url?.absoluteString != "no"){
                if let data = try? Data(contentsOf: url!) {
                        // Create Image and Update Image View
                    tempIngredients.append(UIImage(data: data)!)
                } else{
                    tempIngredients.append(UIImage.init(named: "NoImage")!)//default image
                }
            } else{
                tempIngredients.append(UIImage.init(named: "NoImage")!)
            }
            
        }
        
        self.ingredientPictures = tempIngredients
       // self.ingredientPictures = [UIImage.init(named: "NoImage")!]
        
    }
    
    init(){
        self.name = "None"
        self.ingredients = ["none"]
        self.time = 0
        self.picture = UIImage.init(named: "NoImage")!//default image
        self.ingredientPictures = [UIImage.init(named: "NoImage")!]
    }
    
    enum SerializationError: Error {
        case missing(String)
        case invalid(String, Any)
    }
}
