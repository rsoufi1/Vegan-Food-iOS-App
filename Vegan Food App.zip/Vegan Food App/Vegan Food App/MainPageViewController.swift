//
//  MainPageViewController.swift
//  Vegan Food App
//
//  Created by Raneem Soufi on 9/27/20.
//

import UIKit

class MainPageViewController: UIViewController {

    //MARK: Outlets
    @IBOutlet weak var TitleLabel: UILabel!
    @IBOutlet weak var FeaturedCollectionView: UICollectionView!
    
    private let sectionInsets = UIEdgeInsets(top: 16.0, left: 20.0, bottom: 16.0, right: 20.0)
    var featuredMeals: [Meal] = [Meal]()
    let group = DispatchGroup()
    let group2 = DispatchGroup()
    
    var count: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.FeaturedCollectionView.delegate = self
        self.FeaturedCollectionView.dataSource = self
        // Do any additional setup after loading the view.
       
        //self.FeaturedCollection
        self.getCount()
       
        group.notify(queue: .main){
            print("????")
        }
        
        group.wait()
        
        self.getFeatuedMeals()
        group2.notify(queue: .main){
            print("ufehskhfeukhfeskuhef <3")
            self.FeaturedCollectionView.reloadData()
            
            for each in self.featuredMeals{
                each.printMeal()
            }
        }
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.destination is RecipeViewController {
            //Get destination
            let vc = segue.destination as? RecipeViewController
            
            //Get sender
            let senderCell = sender as? FeaturedFoodCell
            if(senderCell?.index ?? -1 >= 0){
                vc?.meal = featuredMeals[senderCell?.index ?? 0]
            }
            
            print("hewwow uwu")
        }
    }
    
    func getCount(){
        //Get count
        group.enter()
        let url = (URL(string: "https://api.edamam.com/search?q=vegan&app_id=b0e790d0&app_key=2b9e77a8e64c0c00a325ed44719fdb8a&health=vegan&from=0&to=1")!) as URL
        
        let task: URLSessionDataTask = URLSession.shared.dataTask(with: url) { [self] (data, response, error) in
        
            if error == nil{
                if let content = data{
                    do{
                        let jsonResult = try? (JSONSerialization.jsonObject(with: content, options: JSONSerialization.ReadingOptions.mutableContainers) as? [String: Any])
                        //print(result2)
                        //print(result2?[1])
                        count = (jsonResult?["count"] as? Int)!
                        print(count)
                        
                        if(self.count > 100){
                            self.count = 100
                        }
                        
                        group.leave()
                        print("works")
                    } catch {
                        print("nope")
                    }
                }
               
            }
           
        }
        task.resume()
    }
    
    func getFeatuedMeals(){
        
        /*let url = (URL(string: "https://api.edamam.com/search?q=vegan&app_id=b0e790d0&app_key=2b9e77a8e64c0c00a325ed44719fdb8a&health=vegan")!) as URL
        
        let task: URLSessionDataTask = URLSession.shared.dataTask(with: url) { [self] (data, response, error) in
        
            if error == nil{
                if let content = data{
                    do{
                        let jsonResult = try? (JSONSerialization.jsonObject(with: content, options: JSONSerialization.ReadingOptions.mutableContainers) as? [String: Any])
                        let result2 = jsonResult?["hits"] as? [Any]
                        //print(result2)
                        //print(result2?[1])
                        count = (jsonResult?["count"] as? Int)!
                        print(count)
                        let totalNumOfMeals: Int = result2?.count ?? 0
                        
                        print(totalNumOfMeals)
                        
                        //Get 5 random numbers
                        for i in 0...4{
                            
                            let randomMeal: Int = Int.random(in: 0...totalNumOfMeals-1)
                            let item = result2?[randomMeal] as? [String: Any]
                            let anotherItem = (item?["recipe"]) as? [String: Any]
                            //print(anotherItem?["label"])
                            let m = try Meal(json: anotherItem!)
                            featuredMeals.append(m);
                            
                        }
                        
                        group.leave()
                        print("works")
                    } catch {
                        print("nope")
                    }
                }
               
            }
           
        }
        task.resume()*/
        
        
        
        
        //Get 5 random numbers
        var randomItems: [Int] = []
        
        //Set the value of count if count is greater than 100
        
        
        for _ in 0..<5{
            var random = Int.random(in: 0...count)
            while(randomItems.contains(random)){
                random = Int.random(in: 0...count)
            }
            randomItems.append(random)
        }
        //randomItems.removeFirst()
        
        print(randomItems)
        
        //Get the 5 random meals
        
        for i in 0..<5{
            group2.enter()
            let to1 = randomItems[i] + 1
            let urlMeal1 = (URL(string: "https://api.edamam.com/search?q=vegan&app_id=b0e790d0&app_key=2b9e77a8e64c0c00a325ed44719fdb8a&health=vegan&from=\(randomItems[i])&to=\(to1)")!) as URL
            var Meal2: Meal = Meal.init()
            let task2: URLSessionDataTask = URLSession.shared.dataTask(with: urlMeal1) { [self] (data, response, error) in
            
                if error == nil{
                    if let content = data{
                        do{
                            let jsonResult = try? (JSONSerialization.jsonObject(with: content, options: JSONSerialization.ReadingOptions.mutableContainers) as? [String: Any])
                            //print(jsonResult)
                            let result2 = jsonResult?["hits"] as? [Any]
                            if(result2?.count != 0){
                                let item = result2?[0] as? [String: Any]
                                //print(item)
                                let anotherItem = (item?["recipe"]) as? [String: Any]
                                //print(anotherItem)
                                if(!(anotherItem == nil)){
                                    Meal2 = try Meal.init(json: anotherItem!)
                                    featuredMeals.append(Meal2)
                                    print("added")
                                    
                                }
                                
                            }
                            //print(result2)
                            group2.leave()
                            print("works")
                        } catch {
                            print("nope")
                        }
                    }
                   
                }
                //group2.leave()
            }
            task2.resume()
        }
        //group2.leave()
        print("done")
        
    }
}

extension MainPageViewController: UICollectionViewDelegate, UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return featuredMeals.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "featuredFood", for: indexPath) as! FeaturedFoodCell
        if(featuredMeals.count > indexPath.item){
            cell.MealImage.image = featuredMeals[indexPath.item].picture
            //cell.MealImage.alpha = 0.7
            cell.MealImage.layer.cornerRadius = 12.0
            cell.MealImage.clipsToBounds = true
            cell.MealName.text = featuredMeals[indexPath.item].name
            cell.MealName.numberOfLines = 0
            cell.MealName.textColor = UIColor.white
        }
        
        cell.MealImage.layer.sublayers?.removeAll()
        
        let gradientLayer = CAGradientLayer()
        let Color1: UIColor = UIColor.black.withAlphaComponent(0.7)
        let Color2: UIColor = UIColor.black.withAlphaComponent(0)
        gradientLayer.colors = [Color2.cgColor, Color2.cgColor, Color1.cgColor]
        gradientLayer.frame = CGRect.zero

        
        cell.MealImage.layer.insertSublayer(gradientLayer, above: cell.MealImage.layer)
        gradientLayer.frame = cell.contentView.bounds
        cell.GradientView.backgroundColor = Color2
        
        cell.index = indexPath.item
        
        return cell
    }
    
    
    
}

extension MainPageViewController: UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
            
        return CGSize(width: collectionView.visibleSize.width - sectionInsets.left - sectionInsets.right - 30, height: collectionView.visibleSize.height - sectionInsets.bottom - sectionInsets.top)
          
    }
    
    func collectionView(_ collectionView: UICollectionView,
                         layout collectionViewLayout: UICollectionViewLayout,
                         insetForSectionAt section: Int) -> UIEdgeInsets {
       return sectionInsets
     }
    
    func collectionView(_ collectionView: UICollectionView,
                          layout collectionViewLayout: UICollectionViewLayout,
                          minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return sectionInsets.left
      }
    
}

class FeaturedFoodCell: UICollectionViewCell{
   
    @IBOutlet weak var MealName: UILabel!
    
    @IBOutlet weak var Line: UIView!
    
    @IBOutlet weak var GradientView: UIView!
    @IBOutlet weak var MealImage: UIImageView!
    
    var index: Int = -1
    
}
