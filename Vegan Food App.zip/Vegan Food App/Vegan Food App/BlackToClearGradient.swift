//
//  BlackToClearGradient.swift
//  Vegan Food App
//
//  Created by Raneem Soufi on 10/2/20.
//

import Foundation
import UIKit

class BlackGradient: CAGradientLayer {
    let Color1: UIColor = UIColor.black.withAlphaComponent(0.7)
    let Color2: UIColor = UIColor.white.withAlphaComponent(0)
    let colors = [Color2.cgColor, Color2.cgColor, Color1.cgColor]
    let frame = CGRect.zero
    //self
    
}
